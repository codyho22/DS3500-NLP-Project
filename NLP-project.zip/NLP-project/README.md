# NLP-project

NLP Project for DS3500

# Objective

Compare and contract Top five charting for POP music v.s top five charting songs for country music this month.

data gathered on: 4/8/2024
source: https://genius.com/#top-songs
